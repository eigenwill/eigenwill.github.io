---
title: "我的新文章"
date: "2026-10-18"
description: "一两句话，介绍这篇文章。"
category: "学习笔记"
tags: ["笔记", "随想"]
slug: "my-new-post"
draft: false
---

## 从这里开始

写下你的正文。文章标题由上方的 title 设置，正文可以直接从二级标题开始。

## 配一张图片

![示意图](./images/diagram.svg)

将你的图片放入 images/，然后把上面的文件名换成实际图片名。

## 记录一个想法

Markdown 支持 **加粗**、*斜体*、[链接](https://eigenwill.github.io/)、列表和代码。

- 第一个想法
- 第二个想法

```python
print("Keep writing.")
```

> 把 draft 改为 true，可以先将文章保存为草稿。
